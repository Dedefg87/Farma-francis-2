// streamdown stub (temporary fix)
export const Streamdown = (props: any) => null;
export default Streamdown;
