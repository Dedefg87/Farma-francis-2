// Componentes compartilhados
export { FilePreviewAttachment } from './FilePreviewAttachment';
export { MessageMedia } from './MessageMedia';
