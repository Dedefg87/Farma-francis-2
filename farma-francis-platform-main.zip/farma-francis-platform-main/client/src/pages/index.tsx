export { default } from './Diagnostic';
