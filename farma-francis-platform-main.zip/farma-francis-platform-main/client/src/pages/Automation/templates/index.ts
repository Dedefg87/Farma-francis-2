export type { FlowTemplate } from "./types";
// Export the real templates
export { flowTemplates } from "../templates";
