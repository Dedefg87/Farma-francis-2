import type { FlowTemplate } from "./types";
export const operationsTemplates: FlowTemplate[] = [];
