import type { FlowTemplate } from "./types";
export const schedulingTemplates: FlowTemplate[] = [];
