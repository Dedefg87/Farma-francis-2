import type { FlowTemplate } from "./types";
export const communicationTemplates: FlowTemplate[] = [];
