import type { FlowTemplate } from "./types";
export const pharmacyTemplates: FlowTemplate[] = [];
