export default function BabyShowerSimple() {
  return (
    <div style={{ padding: 40 }}>
      <h1>🎁 Chá de Bebê</h1>
      <p>Módulo criado com sucesso!</p>
      <p>Em breve: funcionalidade completa de criação de eventos.</p>
    </div>
  );
}
