-- Migration: 20250324_migrate_broadcast_messages_definitive_FIXED
-- Data: 2025-03-24
-- Propósito: Versão corrigida da migração broadcast (garante normalização e logs)
-- Nota: Esta migration não executa SQL diretamente, apenas documenta as correções aplicadas no código.
-- Ela é mantida para histórico. Pode ser deixada vazia ou com comentários.

-- Nenhuma ação SQL necessária aqui (alterações já estão no código da aplicação).
