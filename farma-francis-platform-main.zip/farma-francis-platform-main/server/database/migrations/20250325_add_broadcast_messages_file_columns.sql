ALTER TABLE broadcast_messages ADD COLUMN file_url TEXT NULL;
ALTER TABLE broadcast_messages ADD COLUMN file_name TEXT NULL;
ALTER TABLE broadcast_messages ADD COLUMN file_type TEXT NULL;
ALTER TABLE broadcast_messages ADD COLUMN file_size INT NULL;
