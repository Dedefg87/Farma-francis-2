ALTER TABLE broadcast_lists ADD COLUMN last_sent_at TIMESTAMP NULL;
