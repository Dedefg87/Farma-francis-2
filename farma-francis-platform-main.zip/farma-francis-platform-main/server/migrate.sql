ALTER TABLE baby_shower_events ADD COLUMN IF NOT EXISTS baby_name VARCHAR(255);
