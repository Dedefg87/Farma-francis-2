ALTER TABLE `conversations` ADD `customer_name` varchar(255);--> statement-breakpoint
ALTER TABLE `conversations` ADD `customer_phone` varchar(50);