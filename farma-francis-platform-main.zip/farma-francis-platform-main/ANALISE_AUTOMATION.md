# Análise da Página /automation - Farma Francis Platform
**Data:** 01/03/2026  
**Analista:** Feds (CTO)  
**Arquivos Analisados:**
- `client/src/pages/Automation/index.tsx`
- `client/src/pages/Automation/hooks/useFlowState.ts`
- `client/src/pages/Automation/components/FlowCard.tsx`

---

## 📊 RESUMO GERAL

A página de automação possui **arquitetura sólida** mas apresenta problemas de UX/UI que dificultam o uso diário. O código está bem estruturado com hooks separados, mas a interface precisa de redesign profissional.

---

## ✅ O QUE FUNCIONA BEM

### 1. Arquitetura Técnica
- ✅ Separação de concerns (hooks, components, types)
- ✅ Integração tRPC funcional
- ✅ State management com useReducer
- ✅ Importação de fluxos N8N funcionando
- ✅ Conversão de formatos (IVR, ReactFlow)
- ✅ Editor visual básico operacional

### 2. Funcionalidades Implementadas
- ✅ CRUD de fluxos visuais
- ✅ Importação/Exportação JSON
- ✅ Duplicação de fluxos
- ✅ Templates pré-configurados
- ✅ Ura (Menus) integrado
- ✅ Validação de integridade de fluxos

---

## ❌ PROBLEMAS CRÍTICOS IDENTIFICADOS

### 1. UX/UI - Design Confuso
**Gravidade:** 🔴 Alta

**Problemas:**
- Abas (Tabs) com nomes pouco claros: "Visual", "Simples", "URA"
- Layout sem hierarquia visual clara
- Cards sem informações de status/contexto
- Ausência de busca/filtros
- Sem indicadores de última execução

### 2. Inconsistência Visual
**Gravidade:** 🟡 Média

**Problemas:**
- Cards em "Automações Simples" não seguem mesmo padrão de "Fluxos Visuais"
- URA tem design diferente das outras abas
- Cores de status inconsistentes (alguns verdes, outros cinzas)
- Tipografia sem padronização

### 3. Falta de Contexto e Informações
**Gravidade:** 🟡 Média

**Problemas:**
- Cards não mostram quando o fluxo foi executado por último
- Sem estatísticas de sucesso/falha
- Sem informação de criação/data
- Não mostra qual trigger o fluxo usa
- Ausência de preview/visualização rápida

### 4. Performance e UX
**Gravidade:** 🟡 Média

**Problemas:**
- Progresso de importação bloqueia UI sem necessidade
- Validação de fluxo pode ser rápida demais (flash)
- Sem loading states em cards individuais
- Não há paginação (pode sobrecarregar com muitos fluxos)

### 5. Editor de Fluxos
**Gravidade:** 🟡 Média

**Problemas:**
- Editor ReactFlow não tem controles de zoom/pan visíveis
- Sem mini-mapa de navegação
- Não há breadcrumbs para voltar da edição
- Configuração de nós fechada em modal (pode ser painel lateral)

---

## 💡 IDEIAS DE MELHORIA - PROPOSTA DE REDESIGN

### 1. Layout Principal - Dashboard Style

```
┌─────────────────────────────────────────────┐
│ HEADER                                      │
│ Título + Busca + Botão "Novo Fluxo"         │
├─────────────────────────────────────────────┤
│ FILTERS                                     │
│ Tabs: Todos | Ativos | Inativos | Falhas   │
│ + Filtros: Canal, Tipo, Data              │
├─────────────────────────────────────────────┤
│                                             │
│  GRID DE CARDS PROFISSIONAIS                │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
│  │ FLUXO 1  │  │ FLUXO 2  │  │ FLUXO 3  │  │
│  │ [Status] │  │ [Status] │  │ [Status] │  │
│  │ Stats    │  │ Stats    │  │ Stats    │  │
│  │ Último   │  │ Último   │  │ Último   │  │
│  │ Execução │  │ Execução │  │ Execução │  │
│  └──────────┘  └──────────┘  └──────────┘  │
│                                             │
├─────────────────────────────────────────────┤
│ PAGINAÇÃO                                  │
└─────────────────────────────────────────────┘
```

### 2. Novo Card de Fluxo - Design Profissional

**Campos Exibidos:**
- ✅ Nome do fluxo (destaque)
- ✅ Badge de status (Ativo/Inativo/Falha)
- ✅ Tipo de trigger (WhatsApp/Instagram/AGENDADO)
- ✅ Contador de execuções (total/sucesso/falha)
- ✅ Última execução (tempo relativo: "2 min atrás")
- ✅ Criado por / Data de criação
- ✅ Mini preview (thumbnail) do fluxo
- ✅ Ações rápidas: Editar | Ativar/Desativar | Mais (⋮)

### 3. Consolidação de Abas

**Proposta:** Eliminar abas "Simples" e "URA", unificar tudo em "Fluxos"

**Motivação:**
- URA é um tipo de fluxo, não uma categoria separada
- Automações "Simples" podem ser cards especiais na mesma lista
- Reduz confusão cognitiva

### 4. Header Profissional

**Elementos:**
- Título "Automações" + subtítulo
- Barra de busca destacada (placeholder: "Buscar fluxos...")
- Botão primário "+ Criar Automação" com dropdown:
  - Fluxo Visual (arrastar e soltar)
  - A partir de Template
  - Importar do N8N
  - Automação Simples (form)

### 5. Filtros Inteligentes

**Filtros Laterais/Barra Superior:**
- Status: Todos | Ativos | Inativos | Com Falhas
- Canal: WhatsApp | Instagram | Universal
- Tipo: Visual | Simples | URA
- Criado por: [Select]
- Período: [Date Range]

### 6. Empty State Profissional

**Quando não houver fluxos:**
- Ilustração (SVG) de fluxo
- Título: "Comece a automatizar"
- Subtítulo: "Crie seu primeiro fluxo para economizar tempo"
- Botão CTA grande: "Criar Primeira Automação"

### 7. Editor Melhorado

**Melhorias:**
- Breadcrumb: Automações > [Nome do Fluxo]
- Sidebar com: Nodes disponíveis | Propriedades | Logs
- Toolbar flutuante: Zoom in/out | Fit view | Mini-map
- Painel lateral para configuração (não modal)
- Auto-save com indicador de status

---

## 🎯 PRIORIDADES DE IMPLEMENTAÇÃO

### Fase 1 - Quick Wins (1 dia)
1. ✅ Redesign dos cards (novo componente FlowCardPro)
2. ✅ Consolidação de abas (remover "Simples", manter apenas 2 abas)
3. ✅ Header profissional com busca
4. ✅ Empty state illustrado

### Fase 2 - Funcionalidades (2 dias)
1. 🔄 Sistema de filtros
2. 🔄 Paginação
3. 🔄 Estatísticas em tempo real (WebSocket)
4. 🔄 Mini preview de fluxos

### Fase 3 - Editor Premium (3 dias)
1. 🔄 Redesign do editor ReactFlow
2.